package PaooGame;

public enum GameState {
    MENU,
    GAME,
    HELP
}
