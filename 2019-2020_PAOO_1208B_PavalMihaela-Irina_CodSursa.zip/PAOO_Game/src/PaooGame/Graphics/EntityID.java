package PaooGame.Graphics;

public enum EntityID {
    player,
    block,
    oposum,
    bullet,
    diamond,
    cherry,
    door,
    gravityblock,
    heart,
    movingblock
}
